package com.stem.multi_dropdown;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
