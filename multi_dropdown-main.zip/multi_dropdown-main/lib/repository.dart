import 'package:multi_dropdown/state_model.dart';

class Repository {
  List<Map> getAll() => _india;

  getLocalByState(String state) => _india
      .map((map) => StateModel.fromJson(map))
      .where((item) => item.state == state)
      .map((item) => item.districts)
      .expand((i) => i)
      .toList();

  List<String> getStates() => _india
      .map((map) => StateModel.fromJson(map))
      .map((item) => item.state)
      .toList();

  List _india = [
    {
      "state": "Html",
      "districts": ["submit button"]
    },
    {
      "state": "django",
      "districts": ["test"]
    },
  ];
}
